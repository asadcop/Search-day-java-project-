package search.day;


import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionListener;
import java.io.*;
import javax.swing.*;

public class SwingDemo extends JFrame implements ActionListener {

    SwingDemo() {
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        super.setResizable(false);
        super.setBounds(50, 50, 1300, 670);

    }
    ImageIcon backImage = new ImageIcon("1.jpg");
    ImageIcon icon = new ImageIcon("2.png");
    JTextField date = new JTextField();
    JTextField month = new JTextField();
    JTextField year = new JTextField();
    JLabel lv = new JLabel(backImage);
    JLabel lv2 = new JLabel(icon);
    JButton su = new JButton("Search Day");
    JLabel d = new JLabel("Day(dd)");
    JLabel m = new JLabel("Month Number(mm)");
    JLabel y = new JLabel("Year(yyyy)");
    {
        lv.setBounds(1, 1, backImage.getIconWidth(), backImage.getIconHeight());
        lv2.setBounds(270, 180, 100, 180);
        date.setBounds(400, 250, 150, 50);
        month.setBounds(580, 250, 180, 50);
        year.setBounds(800, 250, 150, 50);
        su.setBounds(600, 350, 100, 50);
        d.setBounds(405, 180, 100, 100);
        m.setBounds(580, 180, 200, 100);
        y.setBounds(800, 180, 120, 100);
        d.setFont(new Font("Serif", Font.PLAIN, 25));
        m.setFont(new Font("Serif", Font.PLAIN, 20));
        y.setFont(new Font("Serif", Font.PLAIN, 25));
        date.setFont(new Font("Serif", Font.PLAIN, 25));
        date.setForeground(Color.CYAN);
        month.setForeground(Color.CYAN);
        year.setForeground(Color.CYAN);
        month.setFont(new Font("Serif", Font.PLAIN, 25));
        year.setFont(new Font("Serif", Font.PLAIN, 25));
        su.addActionListener(this);
        super.add(d);
        super.add(m);
        super.add(y);
        super.add(su);
        super.add(month);
        super.add(year);
        super.add(date);
        super.add(lv2);
        super.add(lv);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == su) {
            String a = date.getText();
            String b = month.getText();
            String c = year.getText();
            super.setVisible(false);
          
            new cunation(a,b,c);
        }

    }


}
