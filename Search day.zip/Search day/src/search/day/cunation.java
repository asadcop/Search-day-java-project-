package search.day;


public class cunation {

    private int lfy;
    int x,y,z;
    cunation(String s1, String s2, String s3) {
       try{
             x = Integer.parseInt(s1);
             y = Integer.parseInt(s2);
             z = Integer.parseInt(s3);
         }
       catch(Exception e){}
        if ((z % 4 == 0 && z % 100 != 0) || z % 400 == 0) {
            lfy = 1;
        }
        if ((x <= 31 && (y == 1 || y == 3 || y == 7 || y == 8 || y == 10 || y == 12)) || (x <= 30 && (y == 4 || y == 6 || y == 9 || y == 11)) || (x <= 29 && y == 2 && lfy == 1) || (x <= 28 && y == 2 && lfy == 0)) {
            int d = z % 100;
            int c = z / 100;
            if (y == 1) {
                y = 11;
                d = d - 1;
            } else if (y == 2) {
                y = 12;
                d = d - 1;
            } else if (y == 3) {
                y = 1;
            } else if (y == 4) {
                y = 2;
            } else if (y == 5) {
                y = 3;
            } else if (y == 6) {
                y = 4;
            } else if (y == 7) {
                y = 5;
            } else if (y == 8) {
                y = 6;
            } else if (y == 9) {
                y = 7;
            } else if (y == 10) {
                y = 8;
            } else if (y == 11) {
                y = 9;
            } else if (y == 12) {
                y = 10;
            }
            int d1 = d / 4;
            int c1 = c / 4;
            int y1 = ((13 * y) - 1) / 5;
            int sum1 = x + y1;
            int sum2 = d1 + d;
            int sum3 = c1 - (2 * c);
            int b = sum1 + sum2 + sum3;
            int sum = b % 7;
            if (b >= 0) {
                if (sum == 0) {
                    new DayWindow("Sunday");

                } else if (sum == 5) {
                    new DayWindow("Friday");
                } else if (sum == 1) {
                    new DayWindow("Monday");
                } else if (sum == 2) {
                    new DayWindow("Tuesday");
                } else if (sum == 3) {
                    new DayWindow("Wednesday");
                } else if (sum == 4) {
                    new DayWindow("Thursday");
                } else if (sum == 6) {
                    new DayWindow("Saturday");
                }
            } else {
                int b1 = b / 7;
                if (sum == 0) {
                    int su = sum + 7;
                    if (su == 0) {
                        new DayWindow("Sunday");
                    } else if (su == 5) {
                        new DayWindow("Friday");
                    } else if (su == 1) {
                        new DayWindow("Monday");
                    } else if (su == 2) {
                        new DayWindow("Tuesday");
                    } else if (su == 3) {
                        new DayWindow("Wednesday");
                    } else if (su == 4) {
                        new DayWindow("Thursday");
                    } else if (su == 6) {
                        new DayWindow("Saturday");
                    }
                } else {
                    b1 = -(b1 - 1);
                    int b2 = ((7 * b1) + b);
                    int summ = b2;
                    if (summ == 0) {
                        new DayWindow("Sunday");
                    } else if (summ == 5) {
                        new DayWindow("Friday");
                    } else if (summ == 1) {
                        new DayWindow("Monday");

                    } else if (summ == 2) {
                        new DayWindow("Tuesday");

                    } else if (summ == 3) {
                        new DayWindow("Wednesday");

                    } else if (summ == 4) {
                        new DayWindow("Thursday");
                    } else if (summ == 6) {
                        new DayWindow("Saturday");

                    }
                }
            }
        } else {
            new DayWindow("IN");
        }
    }
}
