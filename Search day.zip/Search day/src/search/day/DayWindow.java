package search.day;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;

public class DayWindow  implements ActionListener {

    JButton su = new JButton(">Go Back<");
    JFrame ob = new JFrame("Day");
    DayWindow(String s) {
        ob.setVisible(true);
        ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ob.setResizable(false);
        ob.setBounds(50, 50, 1300, 670);
        su.setBounds(600, 500, 100, 50);
        ob.add(su);
        if (s == "Saturday") {
            ImageIcon backImage = new ImageIcon("sa.jpg");
            JLabel lv = new JLabel(backImage);
            lv.setBounds(50, 50, 1300, 670);

            ob.add(lv);

        } else if (s == "Sunday") {
            ImageIcon backImage = new ImageIcon("sun.jpg");
            JLabel lv = new JLabel(backImage);
            lv.setBounds(50, 50, 1300, 670);
            ob.add(lv);

        } else if (s == "Monday") {
            ImageIcon backImage = new ImageIcon("mon.jpg");
            JLabel lv = new JLabel(backImage);
            lv.setBounds(50, 50, 1300, 670);
            ob.add(lv);
        } else if (s == "Tuesday") {
            ImageIcon backImage = new ImageIcon("tu.jpg");
            JLabel lv = new JLabel(backImage);
            lv.setBounds(50, 50, 1300, 670);
            ob.add(lv);

        } else if (s == "Wednesday") {
            ImageIcon backImage = new ImageIcon("we.jpg");
            JLabel lv = new JLabel(backImage);
            lv.setBounds(50, 50, 1300, 670);
            ob.add(lv);
        } else if (s == "Thursday") {
            ImageIcon backImage = new ImageIcon("th.jpg");
            JLabel lv = new JLabel(backImage);
            lv.setBounds(50, 50, 1300, 670);
            ob.add(lv);
        } else if (s == "Friday") {
            ImageIcon backImage = new ImageIcon("fri.jpg");
            JLabel lv = new JLabel(backImage);
            lv.setBounds(50, 50, 1300, 670);
            ob.add(lv);
        } else if (s == "IN") {
            ImageIcon backImage = new ImageIcon("opps.jpg");
            JLabel lv = new JLabel(backImage);
            lv.setBounds(50, 50, 1300, 670);
            ob.add(lv);
        }
    }

    {
        su.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == su) {
            
            ob.setVisible(false);
            new SwingDemo();
        }
    }
}
